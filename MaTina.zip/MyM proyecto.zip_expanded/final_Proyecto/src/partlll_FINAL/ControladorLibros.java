package partlll_FINAL;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class ControladorLibros   {
	
	private static final String NOMBRE_ARCHIVO = "libros.txt";
    private static final String SEPARADOR_CAMPO = ";";
    private static final String SEPARADOR_REGISTRO = "\n";

       
 

    
    
    
    public static void solicitarDatosParaRegistrar() {
        Scanner tc = new Scanner(System.in);
String codigo;
String codigoA;
String autorA; 
String autor;
String tituloA;
String titulo;   
String Asignatura;
String asignaturaA;
boolean disponible=true;




do {
         codigoA = JOptionPane.showInputDialog("Ingrese Código del Libro (Solo Números):");
        } while (!codigoA.matches("[0-9]*"));
        codigo=codigoA;
       
        

        do {
            tituloA = JOptionPane.showInputDialog("Ingrese Titulo del Libro (Solo Letras):");
        } while (!tituloA.matches("[a-zA-Z ]+"));
        titulo=tituloA;
        
       /* do {
        tituloA=JOptionPane.showInputDialog("ingrese Titulo del libro (Solo letras )");
        }while(!tituloA.matches("[a-zA-Z]+"));
        titulo=tituloA;*/
 
        
 
       do {
           autorA = JOptionPane.showInputDialog("Ingrese Nombre del Autor (Solo Letras):");
       } while (!autorA.matches("[a-zA-Z ]+"));
       autor=autorA;
        
       
  
       while (true) {
           String D = JOptionPane.showInputDialog(null, "¿El libro está disponible? (true/false)");

           if (D != null && (D.equalsIgnoreCase("true") || D.equalsIgnoreCase("false"))) {
               disponible = Boolean.parseBoolean(D);
               break;
           } else {
               JOptionPane.showMessageDialog(null, "Por favor, Ingrese únicamente 'true' o 'false':");
           }
       }

       JOptionPane.showMessageDialog(null, "Disponibilidad del Libro: " + disponible);
       
       
       
        
        String localizacion =JOptionPane.showInputDialog("Ingrese localizacion del libro:");
     
        do {
            asignaturaA = JOptionPane.showInputDialog("Asignatura (solo letras):");
        } while (!asignaturaA.matches("[a-zA-Z ]+"));
        Asignatura=asignaturaA;
        
        
        ControladorLibros.registrar(new Libro(codigo, titulo, autor, localizacion, Asignatura, disponible));
        JOptionPane.showMessageDialog(null, "¡¡¡Libro Registrado correctamente!!!");
    
    }

    public static void registrar(Libro libro) {
        try {
            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(NOMBRE_ARCHIVO, true));
            bufferedWriter.write(libro.getCodigo()
                    + SEPARADOR_CAMPO + libro.getTitulo()
                    + SEPARADOR_CAMPO + libro.getAutor()
                    + SEPARADOR_CAMPO + String.valueOf(libro.isDisponible())
                    + SEPARADOR_CAMPO + libro.getLocalizacion()
                    + SEPARADOR_CAMPO + libro.getAsignatura() + SEPARADOR_REGISTRO);
            bufferedWriter.close();
        } catch (IOException e) {
            System.out.println("Error escribiendo en Archivo... " + e.getMessage());
        }
    }


   
    
    
    public static void guardarLibros(ArrayList<Libro> libros) {
        try {
            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(NOMBRE_ARCHIVO, false));
            for (int x = 0; x < libros.size(); x++) {
                Libro libro = libros.get(x);
                bufferedWriter.write(libro.getCodigo()
                        + SEPARADOR_CAMPO + libro.getTitulo()
                        + SEPARADOR_CAMPO + libro.getAutor()
                        + SEPARADOR_CAMPO + String.valueOf(libro.isDisponible())
                        + SEPARADOR_CAMPO + libro.getLocalizacion()
                        + SEPARADOR_CAMPO + libro.getAsignatura() + SEPARADOR_REGISTRO);

            }
            bufferedWriter.close();
        } catch (IOException e) {
            System.out.println("Error Escribiendo en Archivo... " + e.getMessage());
        }
    }

    public static ArrayList<Libro> obtener() {
        ArrayList<Libro> libros = new ArrayList<>();
        FileReader fileReader = null;
        BufferedReader bufferedReader = null;
        try {
            fileReader = new FileReader(NOMBRE_ARCHIVO);
            bufferedReader = new BufferedReader(fileReader);
            String linea;
            while ((linea = bufferedReader.readLine()) != null) {
                String[] libroComoArreglo = linea.split(SEPARADOR_CAMPO);
                libros.add(new Libro(libroComoArreglo[0], libroComoArreglo[1], libroComoArreglo[2], libroComoArreglo[4],
                        libroComoArreglo[5], Boolean.valueOf(libroComoArreglo[3])));
            }
        } catch (IOException e) {
            System.out.println("Excepción Leyendo Archivo... " + e.getMessage());
        } finally {
            try {
                if (fileReader != null) {
                    fileReader.close();
                }
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
            } catch (IOException e) {
                System.out.println("Excepción Cerrando... " + e.getMessage());
            }
            return libros;
        }
    }

    public static int buscarPorCodigo(String codigo, ArrayList<Libro> libros) {
        for (int x = 0; x < libros.size(); x++) {
            Libro libroActual = libros.get(x);
            if (libroActual.getCodigo().equals(codigo)) {
                return x;
            }
        }
        return -1;
    }

    public static void marcarComoPrestado(String codigoLibro) {
        ArrayList<Libro> libros = ControladorLibros.obtener();
        int indice = ControladorLibros.buscarPorCodigo(codigoLibro, libros);
        if (indice == -1) {
            return;
        }
        libros.get(indice).setDisponible(false);
        ControladorLibros.guardarLibros(libros);
    }

    public static void cambiarSignatura(String codigoLibro, String nuevaSignatura, String nuevaLocalizacion) {
        ArrayList<Libro> libros = ControladorLibros.obtener();
        int indice = ControladorLibros.buscarPorCodigo(codigoLibro, libros);
        if (indice == -1) {
            return;
        }
        libros.get(indice).setAsignatura(nuevaSignatura);
        libros.get(indice).setLocalizacion(nuevaLocalizacion);
        ControladorLibros.guardarLibros(libros);
    }

    public static void solicitarDatosParaCambiarSignatura() {
        Scanner sc = new Scanner(System.in);
        Libro libro = ControladorLibros.imprimirLibrosYPedirSeleccion();
        if (!libro.isDisponible()) {
            JOptionPane.showMessageDialog(null, "¡¡¡ No puedes cambiar un Libro NO Disponible !!!"+ JOptionPane.ERROR_MESSAGE);
            return;
        }
    
       String nuevaLocalizacion=JOptionPane.showInputDialog("Ingrese Nueva Localizacion del Libro ");
     
       String nuevaAsignatura=JOptionPane.showInputDialog("Ingrese Nueva Asignatura  "); 
       ControladorLibros.cambiarSignatura(libro.getCodigo(), nuevaAsignatura, nuevaLocalizacion);
        JOptionPane.showMessageDialog(null, "¡ Localizacion Cambiada Correctamente !");
    }

    public static void imprimirLibros(ArrayList<Libro> libros) {
        System.out.println(
                "+-----+----------+----------------------------------------+--------------------+----------+------------------------------+------------------------------+");
        System.out.printf("|%-5s|%-10s|%-40s|%-20s|%-10s|%-30s|%-30s|\n", "No", "Codigo", "Titulo", "Autor",
                "Disponible",
                "Localizacion", "Asignatura");
        System.out.println(
                "+-----+----------+----------------------------------------+--------------------+----------+------------------------------+------------------------------+");

        for (int x = 0; x < libros.size(); x++) {
            Libro libro = libros.get(x);
            System.out.printf("|%-5d|%-10s|%-40s|%-20s|%-10s|%-30s|%-30s|\n", x + 1, libro.getCodigo(),
                    libro.getTitulo(),
                    libro.getAutor(), libro.isDisponible() ? "Si" : "No", libro.getLocalizacion(),
                    libro.getAsignatura());
            System.out.println(
                    "+-----+----------+----------------------------------------+--------------------+----------+------------------------------+------------------------------+");
        }
    }

    public static Libro imprimirLibrosYPedirSeleccion() {
        ArrayList<Libro> libros = ControladorLibros.obtener();
        Scanner sc = new Scanner(System.in);
        while (true) {
            ControladorLibros.imprimirLibros(libros);
          
            String codigo=JOptionPane.showInputDialog(null, "Ingrese Codigo del Libro:");
            int indice = ControladorLibros.buscarPorCodigo(codigo, libros);
            if (indice == -1) {
             
           JOptionPane.showMessageDialog(null, "¡¡¡ NO existe Libro con ese Codigo !!!");
            } else {
                Libro libro = libros.get(indice);
                if (libro.isDisponible()) {
                    return libro;
                } else {
              
JOptionPane.showMessageDialog(null, "¡ LIBRO OCUPADO ! ");
                }
            }
        }
    }
    
  public static boolean isLetter(String text) {
      for (int i = 0; i < text.length(); i++) {
          char c = text.charAt(i);
          if (!Character.isLetter(c)) {
              return false;
          }
      }
      return true;
  }

  public static boolean isNumber(String text) {
      for (int i = 0; i < text.length(); i++) {
          char c = text.charAt(i);
          if (!Character.isDigit(c)) {
              return false;
          }
      }
      return true;
  }
 /* public static Boolean toBoolean(String input) {
      return Boolean.valueOf(input);
  }*/
  

}