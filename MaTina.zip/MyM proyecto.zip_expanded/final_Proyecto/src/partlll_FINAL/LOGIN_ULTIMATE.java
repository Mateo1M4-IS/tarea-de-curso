package partlll_FINAL;

import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
public class LOGIN_ULTIMATE {

	public static  void main(String[] args) {
		String UsuarioA="MaTina"; 
		String passA="1234$U";
		int c=0;
		
		while(c<4) {
		String  Usuario= JOptionPane.showInputDialog("Ingrese Usuario : ");
			
		JPasswordField passw= new JPasswordField();
		int  contraseñaB= JOptionPane.showConfirmDialog(null,passw, "Ingrese Password :", JOptionPane.OK_CANCEL_OPTION);
		 if (contraseñaB != JOptionPane.OK_OPTION) {
				return;
			}
		
		String contra= new String (passw.getPassword());
		
		
		if(UsuarioA.equalsIgnoreCase(Usuario)&& passA.equalsIgnoreCase(contra)) {
		
			
			JOptionPane.showMessageDialog(null, "¡ Bienvenido a la Biblioteca ! ", "Inicio Exitoso ",
					JOptionPane.INFORMATION_MESSAGE);
			 String eleccion ="";
		        while (!eleccion.equals("9")) {
		        
		           eleccion= JOptionPane.showInputDialog(null, "1. Registrar Nuevo Usuario\n2. Registrar Nuevo Libro\n3. Registrar Prestamo\n4. Ver Usuarios\n5. Ver Libros\n6. Ver Prestamos\n7. Ver Usuarios NO Confiables \n8. Cambiar Localizacion de Libro\n9. Salir\nElija una opcion :");
		      
		            if (eleccion.equals("1")) {
		                ControladorSocios.solicitarDatosParaRegistrar();
		         
		            }
		            if (eleccion.equals("2")) {
		                ControladorLibros.solicitarDatosParaRegistrar();
		           
		            }
		            if (eleccion.equals("3")) {
		                ControladorPrestamos.solicitarDatosYCrearPrestamo();
		           
		            }
		            if (eleccion.equals("4")) {
		                ControladorSocios.imprimirSocios(ControladorSocios.obtener());
		            
		            }
		            if (eleccion.equals("5")) {
		                ControladorLibros.imprimirLibros(ControladorLibros.obtener());
		           
		            }
		            if (eleccion.equals("6")) {
		                ControladorPrestamos.imprimirPrestamos(ControladorPrestamos.obtener());
		           
		            }
		            if (eleccion.equals("7")) {
		                ControladorSocios.imprimirSociosNoFiables(ControladorSocios.obtener());
		           
		            }
		            if (eleccion.equals("8")) {
		                ControladorLibros.solicitarDatosParaCambiarSignatura();
		           
		            }

		            if(eleccion.equals("9")) {

		            	JOptionPane.showMessageDialog(null, "¡¡¡Que tenga un Buen Dia!!!");

		            }
		        }
		return;
		}
		else  {
			JOptionPane.showMessageDialog(null, "Usuario o Contraseña Incorrectos!!! ",null, JOptionPane.ERROR_MESSAGE);
			JOptionPane.showMessageDialog(null, "Intentos Restantes "+c +" de 3");
			c=c+1;
			
		} 
		
	}JOptionPane.showMessageDialog(null, "¡Demasiados Intentos Fallidos!"+"\n ...Acceso Restringido...");
	
	}	
}	